﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebScrapeRESTAPI.Models;
using HtmlAgilityPack;
using System.Net;
using System.IO;
using System.Configuration;
using System.Data;
using Newtonsoft.Json;
using System.Xml.XPath;
using WebScrapeRESTAPI;

namespace WebScraper
{
    public class WebScrape
    {
        string jsonDataSet;

        public WebScrape() { }
        public bool ProcessRequest(WebScrapeRequest theRequest)
        {
            bool success = false;
            WebScrapeMSGQueueDA msgManager = new WebScrapeMSGQueueDA();

            theRequest.StatusID = 1;
            msgManager.PutInProgressStream(theRequest);
            msgManager.PullMsgOffQueue(theRequest);

            theRequest.SourceCode = GetPageSourceCode(theRequest.WebPageAddress);

            if (theRequest.SourceCode.Length > 0)
            {
                success = WriteSourceToFile(theRequest);
            }

            if (success == false)
            {
                theRequest.StatusID = -1;
                msgManager.PutInErrorStream(theRequest);
                return false;
            }

            if(theRequest.ScrapeData.Count > 0)
            {
                theRequest.theDataSet = ScrapeTheData(theRequest);
                if (theRequest.theDataSet != null)
                {
                    jsonDataSet = SerializeDataSet(theRequest.theDataSet);
                    success = WriteJsonToFile(theRequest.wsrID, jsonDataSet);
                }
                else
                {
                    theRequest.StatusID = -1;
                    msgManager.PutInErrorStream(theRequest);
                    success = false;
                }
            }

            if (success)
            {
                success = WriteCompletionJSON(theRequest);
                theRequest.StatusID = 2;
                msgManager.PutInCompleteStream(theRequest);
            }

            return success;
        }
        private bool WriteCompletionJSON(WebScrapeRequest theRequest)
        {
            bool success = false;

            string jsonString = JsonConvert.SerializeObject(theRequest);

            string fileName = theRequest.wsrID + "_" + "WebScrape.json";
            string fileDirectory = ConfigurationManager.AppSettings["RepoDirectory"].ToString();
            string fullFilePath = fileDirectory + fileName;

            try
            {
                if (!Directory.Exists(fileDirectory))
                    Directory.CreateDirectory(fileDirectory);

                if (File.Exists(fullFilePath))
                    File.Delete(fullFilePath);

                StreamWriter sw = new StreamWriter(fullFilePath);
                sw.Write(jsonDataSet);
                sw.Close();

                success = true;
            }
            catch (Exception ex)
            {
                success = false;
            }

            return success;
        }
        private bool WriteJsonToFile(int wsrID, string jsonDataSet)
        {
            bool success = false;
            string fileName = wsrID + "_" + "DataSet.json";
            string fileDirectory = ConfigurationManager.AppSettings["JSONDirectory"].ToString();
            string fullFilePath = fileDirectory + fileName;

            try
            {
                if (!Directory.Exists(fileDirectory))
                    Directory.CreateDirectory(fileDirectory);

                if (File.Exists(fullFilePath))
                    File.Delete(fullFilePath);

                StreamWriter sw = new StreamWriter(fullFilePath);
                sw.Write(jsonDataSet);
                sw.Close();

                success = true;
            }
            catch (Exception ex)
            {
                success = false;
            }

            return success;
        }
        private string SerializeDataSet(DataTable theDataSet)
        {
            string jsonString = string.Empty;
            jsonString = JsonConvert.SerializeObject(theDataSet);
            return jsonString;
        }
        private DataTable ScrapeTheData(WebScrapeRequest wsr)
        {
            bool success = true;
            Dictionary<string, string> dataDefinitions = new Dictionary<string, string>();
            dataDefinitions = ConvertListToDictionary(wsr.ScrapeData);

            string fileName = wsr.wsrID + "_" + "RawSourceSode.txt";
            string fileDirectory = ConfigurationManager.AppSettings["RawSourceDirectory"].ToString();
            string fullFilePath = fileDirectory + fileName;

            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(wsr.SourceCode);
            List<HtmlNodeCollection> dataExtract = new List<HtmlNodeCollection>();

            foreach (string k in dataDefinitions.Keys)
            {
                try
                {
                    XPathExpression expr = XPathExpression.Compile(dataDefinitions[k]);
                    HtmlNodeCollection item = doc.DocumentNode.SelectNodes(dataDefinitions[k]);
                    dataExtract.Add(item);
                }
                catch(XPathException ex)
                {
                    success = false;
                }
            }

            if (success)
            {
                DataTable theData = CreateDataTable(wsr, dataDefinitions, dataExtract);
                return theData;
            }
            else
            {
                return null; 
            }
        }
        private DataTable CreateDataTable(WebScrapeRequest scrapeData, Dictionary<string, string> dataDefinitions, List<HtmlNodeCollection> dataExtract)
        {
            DataTable table = new DataTable();
            
            table.TableName = scrapeData.dataSetName;

            foreach (string key in dataDefinitions.Keys)
            {
                table.Columns.Add(key, typeof(string));
            }

            for(int x = 0; x <= dataExtract.First().Count-1; x++)
            {
                string[] stringArray = new string[dataDefinitions.Keys.Count];

                for (int y = 0; y <= dataDefinitions.Keys.Count-1; y++)
                {
                    stringArray[y] = dataExtract[y][x].InnerText.ToString();
                }

                table.Rows.Add(stringArray);
            }

            return table;
        }
        private bool WriteSourceToFile(WebScrapeRequest wsr)
        {
            bool success = false;
            string fileName = wsr.wsrID + "_" + "RawSourceCode.txt";
            string fileDirectory = ConfigurationManager.AppSettings["RawSourceDirectory"].ToString();
            string fullFilePath = fileDirectory + fileName;

            try
            {
                if (!Directory.Exists(fileDirectory))
                    Directory.CreateDirectory(fileDirectory);

                if (File.Exists(fullFilePath))
                    File.Delete(fullFilePath);

                StreamWriter sw = new StreamWriter(fullFilePath);
                sw.Write(wsr.SourceCode);
                sw.Close();

                success = true;
            }
            catch(Exception ex)
            {
                success = false;
            }

            return success;
        }
        public string GetPageSourceCode(string url)
        {
            string source ="";

            try
            {
                HttpWebRequest webReq = (HttpWebRequest)WebRequest.Create(url);
                HttpWebResponse webResp = (HttpWebResponse)webReq.GetResponse();
                StreamReader sr = new StreamReader(webResp.GetResponseStream());
                source = sr.ReadToEnd();
                sr.Close();
                webResp.Close();
            }
            catch(Exception ex)
            {
                
            }
            return source;
        }
        public Dictionary<string, string> ConvertListToDictionary(List<DataScrapeRequest> listToConvert)
        {
            Dictionary<string, string> newDict = new Dictionary<string, string>();

            foreach (DataScrapeRequest dsr in listToConvert)
            {
                newDict.Add(dsr.dataPoint, dsr.dataXPath);
            }

            return newDict;
        }
    }
}
