﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebScraper;
using WebScrapeRESTAPI.Models;
using WebScrapeRESTAPI;
using Newtonsoft.Json;
using System.IO;

namespace WebScrapeConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            EndToEndServiceTest();
            //List<WebScrapeRequest> wsrList = GenerateTestWebScrapeRequests();
            //WriteJsonTest(wsrList);
            //WebScrapeTesting();
            //WebScrapeIndextesting();
            //WorkerQueueTesting(wsrList);
        }

        private static void EndToEndServiceTest()
        {
            WebScrapeMSGQueueDA msgManager = new WebScrapeMSGQueueDA();
            List<WebScrapeRequest> wsrList = msgManager.ReceiveScrapeRequest();

            if (wsrList.Count > 0)
            {
                try
                {
                    //Parallel.ForEach(wsrList, wsr =>
                    foreach(WebScrapeRequest wsr in wsrList)
                    {
                        wsr.StatusID = 1;
                        msgManager.PutInProgressStream(wsr);
                        msgManager.PullMsgOffQueue(wsr);

                        WebScrape theScrape = new WebScrape();
                        bool success = theScrape.ProcessRequest(wsr);

                        if (success)
                        {
                            wsr.StatusID = 2;
                            msgManager.PutInCompleteStream(wsr);
                        }
                    }//);

                }
                catch (Exception ex)
                {
                    throw;
                }

            }
        }

        private static void WorkerQueueTesting(List<WebScrapeRequest> wsrList)
        {
            bool success = false;
            WebScrapeMSGQueueDA MessagingTest = new WebScrapeMSGQueueDA();

            foreach(WebScrapeRequest w in wsrList)
            {
                Console.WriteLine("Web Address: " + w.WebPageAddress);
                Console.WriteLine("Request ID: " + w.wsrID);
                Console.WriteLine("Request Status: " + w.Status);
                Console.WriteLine("Message ID: " + w.MessageID);
                    
                success = MessagingTest.SendToWorker(w);
            }

            List<WebScrapeRequest> newWSR = MessagingTest.ReceiveScrapeRequest();

            foreach(WebScrapeRequest w in newWSR)
            {
                Console.WriteLine("Web Address: " + w.WebPageAddress);
                Console.WriteLine("Request ID: " + w.wsrID);
                Console.WriteLine("Request Status: " + w.Status);
                Console.WriteLine("Message ID: " + w.MessageID);

                MessagingTest.PullMsgOffQueue(w);
            }

            Console.ReadKey();
        }
        private static List<WebScrapeRequest> GenerateTestWebScrapeRequests()
        {
            List<WebScrapeRequest> testWSRList = new List<WebScrapeRequest>();

            WebScrapeRequest wsr = new WebScrapeRequest();
            wsr.wsrID = 1;
            wsr.StatusID = 0;
            wsr.WebPageAddress = "http://www.espn.com";

            WebScrapeRequest wsr2 = new WebScrapeRequest();
            wsr2.wsrID = 2;
            wsr2.StatusID = 0;
            wsr2.WebPageAddress = "http://www.gamerankings.com/browse.html";
            wsr2.dataSetName = "Game Rankings";
            wsr2.ScrapeData = new List<DataScrapeRequest>();

            DataScrapeRequest dsr = new DataScrapeRequest();
            dsr.dataPoint = "Names";
            dsr.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//a";

            DataScrapeRequest dsr2 = new DataScrapeRequest();
            dsr2.dataPoint = "Scores";
            dsr2.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//span//b";

            wsr2.ScrapeData.Add(dsr);
            wsr2.ScrapeData.Add(dsr2);

            testWSRList.Add(wsr);
            testWSRList.Add(wsr2);

            return testWSRList;
        }    
        private static void WebScrapeIndextesting()
        {
            int index;

            WebScrapeMSGQueueDA MessagingTest = new WebScrapeMSGQueueDA();

            index = MessagingTest.GetRequestIndex();
            Console.WriteLine(index.ToString());
            index++;
            MessagingTest.SetNewIndex(index);

            index = MessagingTest.GetRequestIndex();
            Console.WriteLine(index.ToString());
            index++;
            MessagingTest.SetNewIndex(index);

            index = MessagingTest.GetRequestIndex();
            Console.WriteLine(index.ToString());

            Console.ReadKey();
        }
        private static void WebScrapeTesting()
        { 
            bool success;

            WebScrapeRequest wsr = new WebScrapeRequest();
            wsr.wsrID = 2;
            wsr.StatusID = 0;
            wsr.WebPageAddress = "http://www.gamerankings.com/browse.html";
            wsr.dataSetName = "Game Rankings";
            wsr.ScrapeData = new List<DataScrapeRequest>();

            DataScrapeRequest dsr = new DataScrapeRequest();
            dsr.dataPoint = "Names";
            dsr.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//a";

            DataScrapeRequest dsr2 = new DataScrapeRequest();
            dsr2.dataPoint = "Scores";
            dsr2.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//span//b";

            wsr.ScrapeData.Add(dsr);
            wsr.ScrapeData.Add(dsr2);

            WebScrape TheScrape = new WebScrape();
            success = TheScrape.ProcessRequest(wsr);

            Console.WriteLine("Current Status {0}", wsr.Status);
            Console.ReadKey();
        }
        private static void WriteJsonTest( List<WebScrapeRequest> wsrList)
        {
            string jsonString = JsonConvert.SerializeObject(wsrList);

            StreamWriter sw = new StreamWriter("C:\\EAZETest\\Testing\\Test.json");
            sw.Write(jsonString);
            sw.Close();
        }
    }
}
