﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebScrapeRESTAPI.Models;
using System.Collections.Generic;

namespace WebScraper.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            WebScrapeRequest wsr = new WebScrapeRequest();
            wsr.wsrID = 1;
            wsr.StatusID = 0;
            wsr.WebPageAddress = "http://www.espn.com";

            WebScrape TheScrape = new WebScrape();
            TheScrape.ProcessRequest(wsr);
        }

        [TestMethod]
        public void TestMethod2()
        {
            bool success;

            WebScrapeRequest wsr = new WebScrapeRequest();
            wsr.wsrID = 2;
            wsr.StatusID = 0;
            wsr.WebPageAddress = "http://www.gamerankings.com/browse.html";
            wsr.dataSetName = "Game Rankings";
            wsr.ScrapeData = new List<DataScrapeRequest>();

            DataScrapeRequest dsr = new DataScrapeRequest();
            dsr.dataPoint = "Names";
            dsr.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//a";

            DataScrapeRequest dsr2 = new DataScrapeRequest();
            dsr2.dataPoint = "Scores";
            dsr2.dataXPath = "//*[@id=\"main_col\"]//div//div//table//tr//td//span//b";

            wsr.ScrapeData.Add(dsr);
            wsr.ScrapeData.Add(dsr2);

            WebScrape TheScrape = new WebScrape();
            success = TheScrape.ProcessRequest(wsr);
        }

        [TestMethod]
        public void TestMethod3()
        {

        }
    }
}
