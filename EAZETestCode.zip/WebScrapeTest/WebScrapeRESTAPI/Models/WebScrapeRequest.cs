﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace WebScrapeRESTAPI.Models
{
    public class WebScrapeRequest
    {
        public int wsrID { get; set; }
        public int StatusID { get; set; }
        public string Status
        {
            get
            {
                string msg ="";

                switch (StatusID)
                {
                    case 0:
                        msg = "Submitted";
                        break;
                    case 1:
                        msg = "In Progress";
                        break;
                    case 2:
                        msg = "Complete!";
                        break;
                    case -1:
                        msg = "Error!";
                        break;
                }

                return msg;
            }
        }
        public string WebPageAddress { get; set; }
        public string MessageID { get; set; }
        public string dataSetName { get; set; }
        public string SourceCode { get; set; }
        public DataTable theDataSet { get; set; }
        public List<DataScrapeRequest> ScrapeData { get; set; }
    }

    public class DataScrapeRequest
    {
        public string dataPoint { get; set; }
        public string dataXPath { get; set; }
    }
}