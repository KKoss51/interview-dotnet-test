﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebScrapeRESTAPI.Models;


namespace WebScrapeRESTAPI.Controllers
{
    public class WebScrapeRequestController : ApiController
    {
        // GET: api/WebScrapeRequest
        public IEnumerable<WebScrapeRequest> Get()
        {
            WebScrapeResponseDA responseManager = new WebScrapeResponseDA();

            List<WebScrapeRequest> wsrList = responseManager.ReturnAll();

            return wsrList;
        }

        // GET: api/WebScrapeRequest/5
        public WebScrapeRequest Get(int id)
        {
            WebScrapeResponseDA responseManager = new WebScrapeResponseDA();

            WebScrapeRequest wsr = responseManager.ResponseByID(id);

            return wsr;
        }

        // POST: api/WebScrapeRequest
        public HttpResponseMessage Post([FromBody]WebScrapeRequest value)
        {
            bool successToWorker = false;
            bool successToIndex = false;
            WebScrapeMSGQueueDA requestDA = new WebScrapeMSGQueueDA();

            if(value != null)
            {
                int index = requestDA.GetRequestIndex();
                value.wsrID = index;
                successToIndex = requestDA.SetNewIndex(++index);

                successToWorker = requestDA.SendToWorker(value);
            }

            if (successToWorker)
            {
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created);
                response.Headers.Location = new Uri(Request.RequestUri, string.Format("WebScrapeRequest/{0}", value.wsrID));
                return response;
            }
            else
            {
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.ExpectationFailed);
                return response;
            }

        }

        // PUT: api/WebScrapeRequest/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/WebScrapeRequest/5
        public void Delete(int id)
        {
        }
    }
}
