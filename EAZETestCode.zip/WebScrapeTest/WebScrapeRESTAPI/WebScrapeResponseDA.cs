﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebScrapeRESTAPI.Models;
using Newtonsoft.Json;
using System.IO;
using System.Configuration;

namespace WebScrapeRESTAPI
{
    public class WebScrapeResponseDA
    {
        WebScrapeMSGQueueDA msgManager;
        public WebScrapeResponseDA()
        {
            msgManager = new WebScrapeMSGQueueDA();
        }

        public List<WebScrapeRequest> ReturnAll()
        {
            List<WebScrapeRequest> newList = msgManager.ReceiveAllRequests();

            return newList;
        }

        public WebScrapeRequest ResponseByID(int ID)
        {
            List<WebScrapeRequest> newList = msgManager.ReceiveAllRequests();

            WebScrapeRequest wsr = new WebScrapeRequest();

            wsr = newList.Find(w => w.wsrID == ID);
            
            return wsr;
        }
    }
}