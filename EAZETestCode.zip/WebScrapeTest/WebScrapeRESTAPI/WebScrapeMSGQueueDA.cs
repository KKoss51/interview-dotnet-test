﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Messaging;
using System.Configuration;
using WebScrapeRESTAPI.Models;
using log4net;

namespace WebScrapeRESTAPI
{
    public class WebScrapeMSGQueueDA
    {
        #region Private Fields
        private static ILog _log;
        #endregion
        #region Public Properties
        protected static ILog Log
        {
            get
            {
                if (_log == null)
                {
                    log4net.Config.XmlConfigurator.Configure();
                    _log = LogManager.GetLogger("Default");
                }
                return _log;
            }
        }
        #endregion

        string indexPath;
        string workerPath;
        string inprogressPath;
        string errorPath;
        string completePath;
        MessageQueue indexQueue;
        MessageQueue workerQueue;
        MessageQueue inprogressQueue;
        MessageQueue errorQueue;
        MessageQueue completeQueue;

        public WebScrapeMSGQueueDA()
        {
            indexPath = ConfigurationManager.AppSettings["indexPath"].ToString();
            workerPath = ConfigurationManager.AppSettings["workerPath"].ToString();
            inprogressPath = ConfigurationManager.AppSettings["inprogressPath"].ToString();
            errorPath = ConfigurationManager.AppSettings["errorPath"].ToString();
            completePath = ConfigurationManager.AppSettings["completePath"].ToString();

            if (MessageQueue.Exists(@indexPath))
            {
                indexQueue = new MessageQueue(@indexPath);
            }
            else
            {
                MessageQueue.Create(@indexPath);
                indexQueue = new MessageQueue(@indexPath);
            }

            if (MessageQueue.Exists(@workerPath))
            {
                workerQueue = new MessageQueue(@workerPath);
            }
            else
            {
                MessageQueue.Create(@workerPath);
                workerQueue = new MessageQueue(@workerPath);
            }

            if (MessageQueue.Exists(@inprogressPath))
            {
                inprogressQueue = new MessageQueue(@inprogressPath);
            }
            else
            {
                MessageQueue.Create(@inprogressPath);
                inprogressQueue = new MessageQueue(@inprogressPath);
            }

            if (MessageQueue.Exists(@errorPath))
            {
                errorQueue = new MessageQueue(@errorPath);
            }
            else
            {
                MessageQueue.Create(@errorPath);
                errorQueue = new MessageQueue(@errorPath);
            }

            if (MessageQueue.Exists(@completePath))
            {
                completeQueue = new MessageQueue(@completePath);
            }
            else
            {
                MessageQueue.Create(@completePath);
                completeQueue = new MessageQueue(@completePath);
            }
        }
        public bool SendToWorker(WebScrapeRequest scrapeRequest)
        {
            try
            {
                Message newMsg = new Message();
                newMsg.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                newMsg.Body = scrapeRequest;

                workerQueue.Send(newMsg);

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public List<WebScrapeRequest> ReceiveScrapeRequest()
        {
            Log.Debug("Entering ReceiveScrapeRequest");

            List<WebScrapeRequest> wsrList = new List<WebScrapeRequest>();
            try
            {
                List<Message> newMessages = workerQueue.GetAllMessages().ToList();

                foreach (Message m in newMessages)
                {
                    m.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                    WebScrapeRequest newReq = (WebScrapeRequest)m.Body;
                    newReq.MessageID = m.Id;
                    wsrList.Add(newReq);
                }
            }
            catch(Exception ex)
            {
                Log.DebugFormat("Error Receiving Messages: {0}", ex.Message);
                Log.Error(ex);
                wsrList = null;
            }

            return wsrList;
        }
        public List<WebScrapeRequest> ReceiveInProgressRequests()
        {
            List<WebScrapeRequest> wsrList = new List<WebScrapeRequest>();
            try
            {
                List<Message> newMessages = inprogressQueue.GetAllMessages().ToList();

                foreach (Message m in newMessages)
                {
                    m.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                    WebScrapeRequest newReq = (WebScrapeRequest)m.Body;
                    newReq.MessageID = m.Id;
                    wsrList.Add(newReq);
                }
            }
            catch (Exception ex)
            {
                wsrList = null;
            }

            return wsrList;
        }
        public List<WebScrapeRequest> ReceiveCompleteRequests()
        {
            List<WebScrapeRequest> wsrList = new List<WebScrapeRequest>();
            try
            {
                List<Message> newMessages = completeQueue.GetAllMessages().ToList();

                foreach (Message m in newMessages)
                {
                    m.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                    WebScrapeRequest newReq = (WebScrapeRequest)m.Body;
                    newReq.MessageID = m.Id;
                    wsrList.Add(newReq);
                }
            }
            catch (Exception ex)
            {
                wsrList = null;
            }

            return wsrList;
        }
        public List<WebScrapeRequest> ReceiveErrorRequests()
        {
            List<WebScrapeRequest> wsrList = new List<WebScrapeRequest>();
            try
            {
                List<Message> newMessages = errorQueue.GetAllMessages().ToList();

                foreach (Message m in newMessages)
                {
                    m.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                    WebScrapeRequest newReq = (WebScrapeRequest)m.Body;
                    newReq.MessageID = m.Id;
                    wsrList.Add(newReq);
                }
            }
            catch (Exception ex)
            {
                wsrList = null;
            }

            return wsrList;
        }
        public List<WebScrapeRequest> ReceiveAllRequests()
        {
            List<WebScrapeRequest> temp1 = ReceiveScrapeRequest();
            List<WebScrapeRequest> temp2 = temp1.Concat(ReceiveInProgressRequests()).ToList();
            List<WebScrapeRequest> temp3 = temp2.Concat(ReceiveErrorRequests()).ToList();
            List<WebScrapeRequest> fullList = temp3.Concat(ReceiveCompleteRequests()).ToList();

            return fullList;
        }
        public void PullMsgOffQueue(WebScrapeRequest wsr)
        {
            Message item = workerQueue.ReceiveById(wsr.MessageID);
        }
        public void PutInProgressStream(WebScrapeRequest wsr)
        {
            try
            {
                Message newMsg = new Message();
                newMsg.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                newMsg.Body = wsr;

                inprogressQueue.Send(newMsg);
            }
            catch (Exception ex)
            {

            }
        }
        public void PutInErrorStream(WebScrapeRequest wsr)
        {
            List<WebScrapeRequest> currentInProgress = ReceiveInProgressRequests();
            WebScrapeRequest wr = currentInProgress.Find(t => t.wsrID == wsr.wsrID);
            inprogressQueue.ReceiveById(wr.MessageID);

            try
            {
                Message newMsg = new Message();
                newMsg.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                newMsg.Body = wsr;

                errorQueue.Send(newMsg);
            }
            catch (Exception ex)
            {

            }
        }
        public void PutInCompleteStream(WebScrapeRequest wsr)
        {
            List<WebScrapeRequest> currentInProgress = ReceiveInProgressRequests();
            WebScrapeRequest wr = currentInProgress.Find(t => t.wsrID == wsr.wsrID);
            inprogressQueue.ReceiveById(wr.MessageID);

            try
            {
                Message newMsg = new Message();
                newMsg.Formatter = new XmlMessageFormatter(new Type[] { typeof(WebScrapeRequest) });
                newMsg.Body = wsr;

                completeQueue.Send(newMsg);
            }
            catch (Exception ex)
            {

            }
        }
        public int GetRequestIndex()
        {
            int i;
            List<Message> newIndex = indexQueue.GetAllMessages().ToList();

            if(newIndex.Count == 0)
            {
                i= 0;
            }       
            else
            {
                Message theIndex = indexQueue.Receive();
                theIndex.Formatter = new XmlMessageFormatter(new Type[] { typeof( System.Int32 ) });
                i = (int)theIndex.Body;
            }

            return i;
        }
        public bool SetNewIndex(int newIndex)
        {
            try
            {
                Message newMsg = new Message();
                newMsg.Formatter = new XmlMessageFormatter(new Type[] { typeof(System.Int32) });
                newMsg.Body = newIndex;

                indexQueue.Send(newMsg);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        } 
        
    }
}