﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebScraper;
using WebScrapeRESTAPI;
using WebScrapeRESTAPI.Models;
using System.Threading;
using System.Net;
using System.Net.Http;
using System.Configuration;
using log4net;

namespace WebScrapeWindowsService
{
    class WebScrapeWork 
    {
        #region Private Fields
        private static ILog _log;
        #endregion
        #region Public Properties
        protected static ILog Log
        {
            get
            {
                if (_log == null)
                {
                    log4net.Config.XmlConfigurator.Configure();
                    _log = LogManager.GetLogger("Default");
                }
                return _log;
            }
        }
        #endregion

        private WebScrapeMSGQueueDA msgManager;
        // procces task
        private Task _processQueueTask;
        // task monitor 
        private Task _monitorTasks;

        private CancellationTokenSource _executionQueueCancelationObj;
        private CancellationTokenSource _monitorCancelationObj;

        public WebScrapeWork()
        {
            Log.Info("Entering constructor");
            _executionQueueCancelationObj = new CancellationTokenSource();
            _monitorCancelationObj = new CancellationTokenSource();

            _processQueueTask = new Task(ProcessQueuedRequests, _executionQueueCancelationObj.Token);
            _monitorTasks = new Task(MonitorTasks, _monitorCancelationObj.Token);

            msgManager = new WebScrapeMSGQueueDA();
        }

        public void OnStart()
        {
            Log.Info("Starting Service!");

            _processQueueTask.Start();
            _monitorTasks.Start();
        }

        public void OnStop()
        {
            Log.Info("Stopping Service");

            _executionQueueCancelationObj.Cancel();
            _monitorCancelationObj.Cancel();
        }

       

        /// <summary>
        /// Process queued req. This will pick up a message to be processed.
        /// </summary>
        private void ProcessQueuedRequests()
        {
            Log.Info("Processing Queue");
            try
            {
                while (!_executionQueueCancelationObj.IsCancellationRequested)
                {
                    //check if any requests to be proecessed and process.
                    Log.Debug("Retrieving Queue");
                    List<WebScrapeRequest> wsrList = msgManager.ReceiveScrapeRequest();
                    if(wsrList != null)
                        Log.DebugFormat("Requests/Messages Received: {0}", wsrList.Count);
                    Log.Debug("Queue Retrieved");

                    if (wsrList != null)
                    {
                        if (wsrList.Count > 0)
                        {
                            try
                            {
                                Log.Debug("Preparing to Process Requests!");
                                Parallel.ForEach(wsrList, wsr =>
                                {
                                    WebScrape theScrape = new WebScrape();
                                    bool success = theScrape.ProcessRequest(wsr);
                                });
                                Log.Debug("Processing Requests Complete");

                            }
                            catch (Exception ex)
                            {
                                Log.DebugFormat("Error during Processing: {0}", ex.Message);
                                Log.Error(ex);
                                throw;
                            }

                        }
                    }

                    Thread.Sleep(4000);
                }
            }
            catch (Exception ex)
            {
                Log.DebugFormat("General Error: {0}", ex.Message);
                Log.Error(ex);
                _executionQueueCancelationObj.Cancel();
                throw;
            }
        }

        /// <summary>
        /// monitor other tasks (currently MonitorQueue and ProcessQueuedRequests)
        /// </summary>
        private void MonitorTasks()
        {
            while (true)
            {
                if (_monitorCancelationObj.IsCancellationRequested)
                {
                    break;
                }

                if (_executionQueueCancelationObj.IsCancellationRequested)
                {
                    // sleep a few before restarting (configure if necessary)
                    Thread.Sleep(2000);

                    switch (_processQueueTask.Status)
                    {
                        case TaskStatus.RanToCompletion:
                            _processQueueTask.Dispose();
                            break;
                        default:
                            break;
                    }
                    _executionQueueCancelationObj = new CancellationTokenSource();
                    _processQueueTask = new Task(ProcessQueuedRequests, _executionQueueCancelationObj.Token);
                    _processQueueTask.Start();
                }

                Thread.Sleep(5000);
            }
        }

        #region dispose
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                switch (_processQueueTask.Status)
                {
                    case TaskStatus.Canceled:
                    case TaskStatus.Faulted:
                    case TaskStatus.RanToCompletion:
                        _processQueueTask.Dispose();
                        break;
                    default:
                        break;
                }

                switch (_monitorTasks.Status)
                {
                    case TaskStatus.Canceled:
                    case TaskStatus.Faulted:
                    case TaskStatus.RanToCompletion:
                        _monitorTasks.Dispose();
                        break;
                    default:
                        break;
                }

                _executionQueueCancelationObj.Dispose();
                _monitorCancelationObj.Dispose();
            }
            // free native resources
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}