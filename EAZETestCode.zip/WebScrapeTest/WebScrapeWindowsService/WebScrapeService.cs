﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using Topshelf;
using log4net;

namespace WebScrapeWindowsService
{
    class WebScrapeService
    {
        #region Private Fields
        private static ILog _log;
        #endregion
        #region Public Properties
        protected static ILog Log
        {
            get
            {
                if (_log == null)
                {
                    log4net.Config.XmlConfigurator.Configure();
                    _log = LogManager.GetLogger("Default");
                }
                return _log;
            }
        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            Log.Debug("Service is Starting!");
            try
            {
                HostFactory.New(n =>
                {
                    n.Service<WebScrapeWork>(s =>
                    {
                        s.ConstructUsing(name => new WebScrapeWork());
                        s.WhenStarted(tc => tc.OnStart()); // registering the function to be called when service starts
                        s.WhenStopped(tc => tc.OnStop());  // registering the function to be called when service stops                        
                    });

                    n.RunAsLocalSystem();

                    n.SetDescription("This Service will generate Scrapes and DataSets from websites");
                    n.SetDisplayName("Eaze.WebScrapeService");
                    n.SetServiceName("Eaze.WebScrapeService");

                    n.StartAutomatically();

                    n.EnableServiceRecovery(rc =>
                    {
                        Log.Info("Host restarting the service");
                        rc.RestartService(5); // restart the service after 1 minute           
                    });
                }).Run();

            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
